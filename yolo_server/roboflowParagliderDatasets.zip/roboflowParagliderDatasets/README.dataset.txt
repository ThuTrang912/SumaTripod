# Identify Objects > 2024-11-28 1:22am
https://universe.roboflow.com/smartcamera-fv1bc/identify-objects-qfzls

Provided by a Roboflow user
License: CC BY 4.0

